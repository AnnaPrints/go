package main

func IntMin(a, b int) int {
	if a < b {
		return a
	} else {
		return b
	}
}


