package main

import "fmt"

func main() {
	log("Mike")
}


func log(name string) {
	fmt.Println("Name:")
}
